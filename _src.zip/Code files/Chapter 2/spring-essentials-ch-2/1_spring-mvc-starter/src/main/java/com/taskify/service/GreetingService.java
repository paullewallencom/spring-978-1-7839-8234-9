package com.taskify.service;

public interface GreetingService {
	void greet(String message);
}