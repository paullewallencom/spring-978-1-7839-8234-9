# Spring Essentials - Chapter 1 #

This is the root project for Chapter 1 - Getting Started with Spring Core.

It has five sub-projects, for progressive levels of complexity.