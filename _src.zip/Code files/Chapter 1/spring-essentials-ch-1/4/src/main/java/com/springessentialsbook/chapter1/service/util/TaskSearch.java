package com.springessentialsbook.chapter1.service.util;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("request")
public class TaskSearch {

}
