package com.springessentialsbook.chapter4;

public class ClientInfoBean {
    private String clientName;
    private String clientMessage;
    public String getClientMessage() { return clientMessage; }
    public String getClientName() {
        return clientName;
    }
}
